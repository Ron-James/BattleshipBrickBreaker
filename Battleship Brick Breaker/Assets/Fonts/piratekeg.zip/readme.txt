TrueTypeFont: Pirate Keg (Regular, Italic)
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there Pirate football fans! Represent the spirit of the east with this adapted font.
It's one of my last requested fonts before summer of '01
 A few tricks here: An amperstand will spell out the Skully logo. Get lots of cool bonehead
gear there by visiting them on the web at www.Skully.com Also, an underscore
will net you a pirate's sword. If you like the font, please email me simply let me know.
 Im a sucker for flattery :-) Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"